// api/license.js - Servidor de Licenciamento para Vercel
const crypto = require('crypto');

// Banco de dados em memória (em produção, usar MongoDB Atlas gratuito)
const licenses = new Map();
const machines = new Map();

// Gerar chave de licença
function generateLicenseKey() {
  return crypto.randomBytes(16).toString('hex');
}

// Gerar hash da máquina
function generateMachineHash(machineInfo) {
  return crypto.createHash('md5').update(machineInfo).digest('hex');
}

// Comparar versões
function compareVersions(version1, version2) {
  const v1parts = version1.split('.').map(Number);
  const v2parts = version2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(v1parts.length, v2parts.length); i++) {
    const v1part = v1parts[i] || 0;
    const v2part = v2parts[i] || 0;
    
    if (v1part < v2part) return -1;
    if (v1part > v2part) return 1;
  }
  
  return 0;
}

// Middleware para CORS
function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

// Solicitar nova licença
export default async function handler(req, res) {
  if (cors(req, res)) return;
  
  const { method, body } = req;
  
  try {
    if (method === 'POST' && req.url.includes('/request')) {
      const { machine_id, app_version, company } = body;
      
      // Validar empresa autorizada
      if (company !== 'Wikitelecom') {
        return res.status(403).json({ 
          error: 'Empresa não autorizada',
          code: 'UNAUTHORIZED_COMPANY'
        });
      }
      
      // Verificar se já existe licença para esta máquina
      if (machines.has(machine_id)) {
        const existingLicense = machines.get(machine_id);
        return res.status(200).json({
          key: existingLicense.key,
          status: 'active',
          expires_at: existingLicense.expires_at,
          message: 'Licença já existe para esta máquina'
        });
      }
      
      // Criar nova licença
      const licenseKey = generateLicenseKey();
      const expiresAt = new Date();
      expiresAt.setFullYear(expiresAt.getFullYear() + 1); // 1 ano
      
      const licenseData = {
        key: licenseKey,
        company: company,
        machine_id: machine_id,
        app_version: app_version,
        created_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        status: 'active'
      };
      
      licenses.set(licenseKey, licenseData);
      machines.set(machine_id, licenseData);
      
      console.log(`Nova licença criada: ${licenseKey} para ${company}`);
      
      return res.status(200).json({
        key: licenseKey,
        status: 'active',
        expires_at: expiresAt.toISOString(),
        message: 'Licença criada com sucesso'
      });
    }
    
    if (method === 'POST' && req.url.includes('/validate')) {
      const { license_key, machine_id } = body;
      
      const license = licenses.get(license_key);
      const machineLicense = machines.get(machine_id);
      
      if (!license || !machineLicense) {
        return res.status(403).json({ 
          valid: false,
          error: 'Licença não encontrada',
          code: 'LICENSE_NOT_FOUND'
        });
      }
      
      if (license.key !== machineLicense.key) {
        return res.status(403).json({ 
          valid: false,
          error: 'Licença não corresponde à máquina',
          code: 'MACHINE_MISMATCH'
        });
      }
      
      const now = new Date();
      const expiresAt = new Date(license.expires_at);
      
      if (now > expiresAt) {
        return res.status(403).json({ 
          valid: false,
          error: 'Licença expirada',
          code: 'LICENSE_EXPIRED'
        });
      }
      
      console.log(`Licença validada: ${license_key} para máquina ${machine_id}`);
      
      return res.status(200).json({
        valid: true,
        expires_at: license.expires_at,
        company: license.company,
        created_at: license.created_at
      });
    }
    
    if (method === 'GET' && req.url.includes('/status')) {
      return res.status(200).json({
        status: 'online',
        total_licenses: licenses.size,
        total_machines: machines.size,
        server_time: new Date().toISOString()
      });
    }
    
    return res.status(404).json({ error: 'Endpoint não encontrado' });
    
  } catch (error) {
    console.error('Erro no servidor:', error);
    return res.status(500).json({ 
      error: 'Erro interno do servidor',
      message: error.message
    });
  }
}
