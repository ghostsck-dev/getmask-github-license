// api/updates.js - Servidor de Atualizações para Vercel
const fs = require('fs');
const path = require('path');

// Configuração de versões
const VERSIONS = {
  '1.0.0': {
    version: '1.0.0',
    build: 1,
    release_date: '2025-01-07',
    changelog: 'Versão inicial do GetMask com integração Nagios',
    download_url: 'https://github.com/patrickbraga/getmask/releases/download/v1.0.0/GetMask.exe',
    file_size: '2.3 MB',
    requirements: 'Windows 10 ou superior'
  },
  '1.1.0': {
    version: '1.1.0',
    build: 2,
    release_date: '2025-01-07',
    changelog: 'Sistema de licenciamento e atualizações automáticas implementado',
    download_url: 'https://github.com/patrickbraga/getmask/releases/download/v1.1.0/GetMask.exe',
    file_size: '2.5 MB',
    requirements: 'Windows 10 ou superior'
  },
  '1.2.0': {
    version: '1.2.0',
    build: 3,
    release_date: '2025-01-15',
    changelog: 'Melhorias na interface e correções de bugs',
    download_url: 'https://github.com/patrickbraga/getmask/releases/download/v1.2.0/GetMask.exe',
    file_size: '2.6 MB',
    requirements: 'Windows 10 ou superior'
  }
};

// Versão mais recente
const LATEST_VERSION = '1.2.0';

// Comparar versões
function compareVersions(version1, version2) {
  const v1parts = version1.split('.').map(Number);
  const v2parts = version2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(v1parts.length, v2parts.length); i++) {
    const v1part = v1parts[i] || 0;
    const v2part = v2parts[i] || 0;
    
    if (v1part < v2part) return -1;
    if (v1part > v2part) return 1;
  }
  
  return 0;
}

// Middleware para CORS
function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return true;
  }
  return false;
}

// Verificar atualizações
export default async function handler(req, res) {
  if (cors(req, res)) return;
  
  const { method, query } = req;
  
  try {
    if (method === 'GET' && req.url.includes('/check')) {
      const currentVersion = query.current_version || '1.0.0';
      
      // Extrair versão base (sem build number)
      const baseVersion = currentVersion.split('+')[0];
      
      if (compareVersions(baseVersion, LATEST_VERSION) < 0) {
        const latestInfo = VERSIONS[LATEST_VERSION];
        
        console.log(`Atualização disponível: ${baseVersion} -> ${LATEST_VERSION}`);
        
        return res.status(200).json({
          has_update: true,
          current_version: baseVersion,
          latest_version: LATEST_VERSION,
          version: LATEST_VERSION,
          changelog: latestInfo.changelog,
          download_url: latestInfo.download_url,
          file_size: latestInfo.file_size,
          release_date: latestInfo.release_date,
          requirements: latestInfo.requirements
        });
      } else {
        console.log(`Versão atual: ${baseVersion} (mais recente)`);
        
        return res.status(200).json({
          has_update: false,
          current_version: baseVersion,
          latest_version: LATEST_VERSION,
          message: 'Você está usando a versão mais recente'
        });
      }
    }
    
    if (method === 'GET' && req.url.includes('/latest')) {
      const latestInfo = VERSIONS[LATEST_VERSION];
      
      return res.status(200).json({
        version: LATEST_VERSION,
        ...latestInfo
      });
    }
    
    if (method === 'GET' && req.url.includes('/versions')) {
      return res.status(200).json({
        versions: Object.values(VERSIONS),
        latest: LATEST_VERSION
      });
    }
    
    if (method === 'GET' && req.url.includes('/status')) {
      return res.status(200).json({
        status: 'online',
        latest_version: LATEST_VERSION,
        total_versions: Object.keys(VERSIONS).length,
        server_time: new Date().toISOString()
      });
    }
    
    return res.status(404).json({ error: 'Endpoint não encontrado' });
    
  } catch (error) {
    console.error('Erro no servidor de atualizações:', error);
    return res.status(500).json({ 
      error: 'Erro interno do servidor',
      message: error.message
    });
  }
}
