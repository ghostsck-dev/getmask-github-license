// GetMask License Server - Entry Point
const express = require('express');
const app = express();

app.use(express.json());

// Import API routes
const licenseHandler = require('./api/license');
const updatesHandler = require('./api/updates');

// License endpoints
app.post('/api/license', licenseHandler);
app.post('/api/license/request', licenseHandler);
app.post('/api/license/validate', licenseHandler);

// Updates endpoints
app.get('/api/updates', updatesHandler);

// Health check
app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'online', 
    service: 'GetMask License Server',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({ 
    message: 'GetMask License Server is running!',
    endpoints: [
      'GET /api/status - Health check',
      'POST /api/license/request - Request new license',
      'POST /api/license/validate - Validate license',
      'GET /api/updates - Check for updates'
    ]
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`GetMask License Server running on port ${PORT}`);
});

module.exports = app;
